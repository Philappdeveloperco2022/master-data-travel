module.exports = {
    printWidth: 140,
    singleQuote: true,
    jsxSingleQuote: true,
    trailingComma: 'none',
    tabWidth: 4,
    semi: false,
    endOfLine: 'auto'
}
