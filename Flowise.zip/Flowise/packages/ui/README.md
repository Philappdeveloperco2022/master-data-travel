<!-- markdownlint-disable MD030 -->

# Flowise UI

React frontend ui for Flowise.

![Flowise](https://github.com/FlowiseAI/Flowise/blob/main/images/flowise.gif?raw=true)

Install:

```bash
npm i flowise-ui
```

## License

Source code in this repository is made available under the [MIT License](https://github.com/FlowiseAI/Flowise/blob/master/LICENSE.md).
